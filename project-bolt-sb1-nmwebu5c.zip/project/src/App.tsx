import React, { useState } from 'react';
import { Search, Car, Filter, ShoppingCart, Heart, User, ChevronDown, ChevronRight } from 'lucide-react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import CarList from './components/CarList';
import Footer from './components/Footer';
import { CarType } from './types';

function App() {
  const [searchTerm, setSearchTerm] = useState('');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 100000]);
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);

  const handleSearch = (term: string) => {
    setSearchTerm(term);
  };

  const handlePriceRangeChange = (range: [number, number]) => {
    setPriceRange(range);
  };

  const handleBrandSelect = (brand: string) => {
    if (selectedBrands.includes(brand)) {
      setSelectedBrands(selectedBrands.filter(b => b !== brand));
    } else {
      setSelectedBrands([...selectedBrands, brand]);
    }
  };

  const handleTypeSelect = (type: string) => {
    if (selectedTypes.includes(type)) {
      setSelectedTypes(selectedTypes.filter(t => t !== type));
    } else {
      setSelectedTypes([...selectedTypes, type]);
    }
  };

  const toggleFavorite = (carId: string) => {
    if (favorites.includes(carId)) {
      setFavorites(favorites.filter(id => id !== carId));
    } else {
      setFavorites([...favorites, carId]);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar onSearch={handleSearch} />
      <Hero />
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-6">
          <div className="w-full md:w-1/4 bg-white p-4 rounded-lg shadow-sm">
            <h2 className="text-xl font-bold mb-4">Filters</h2>
            
            <div className="mb-6">
              <h3 className="font-semibold mb-2 flex items-center">
                Price Range <ChevronDown className="ml-auto h-4 w-4" />
              </h3>
              <div className="mt-2">
                <div className="flex justify-between mb-2">
                  <span>${priceRange[0].toLocaleString()}</span>
                  <span>${priceRange[1].toLocaleString()}</span>
                </div>
                <input 
                  type="range" 
                  min="0" 
                  max="100000" 
                  step="5000"
                  value={priceRange[1]}
                  onChange={(e) => handlePriceRangeChange([priceRange[0], parseInt(e.target.value)])}
                  className="w-full"
                />
              </div>
            </div>
            
            <div className="mb-6">
              <h3 className="font-semibold mb-2 flex items-center">
                Brand <ChevronDown className="ml-auto h-4 w-4" />
              </h3>
              <div className="space-y-2 mt-2">
                {['Toyota', 'Honda', 'Ford', 'BMW', 'Mercedes', 'Tesla'].map(brand => (
                  <label key={brand} className="flex items-center">
                    <input 
                      type="checkbox" 
                      checked={selectedBrands.includes(brand)}
                      onChange={() => handleBrandSelect(brand)}
                      className="mr-2"
                    />
                    {brand}
                  </label>
                ))}
              </div>
            </div>
            
            <div className="mb-6">
              <h3 className="font-semibold mb-2 flex items-center">
                Vehicle Type <ChevronDown className="ml-auto h-4 w-4" />
              </h3>
              <div className="space-y-2 mt-2">
                {['Sedan', 'SUV', 'Truck', 'Coupe', 'Hatchback', 'Electric'].map(type => (
                  <label key={type} className="flex items-center">
                    <input 
                      type="checkbox" 
                      checked={selectedTypes.includes(type)}
                      onChange={() => handleTypeSelect(type)}
                      className="mr-2"
                    />
                    {type}
                  </label>
                ))}
              </div>
            </div>
            
            <button className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition">
              Apply Filters
            </button>
          </div>
          
          <div className="w-full md:w-3/4">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">Available Cars</h2>
              <div className="flex items-center">
                <span className="mr-2">Sort by:</span>
                <select className="border rounded-md p-1">
                  <option>Price: Low to High</option>
                  <option>Price: High to Low</option>
                  <option>Newest First</option>
                  <option>Most Popular</option>
                </select>
              </div>
            </div>
            
            <CarList 
              searchTerm={searchTerm}
              priceRange={priceRange}
              selectedBrands={selectedBrands}
              selectedTypes={selectedTypes}
              favorites={favorites}
              onToggleFavorite={toggleFavorite}
            />
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default App;