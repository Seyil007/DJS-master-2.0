import React, { useState } from 'react';
import { Search, ShoppingCart, Heart, User, Menu, X, Car } from 'lucide-react';

interface NavbarProps {
  onSearch: (term: string) => void;
}

const Navbar: React.FC<NavbarProps> = ({ onSearch }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    onSearch(e.target.value);
  };

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <nav className="bg-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <a href="/" className="flex items-center">
              <Car className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold text-gray-800">AutoMarket</span>
            </a>
          </div>

          <div className="hidden md:flex items-center flex-1 mx-10">
            <div className="relative w-full max-w-xl">
              <input
                type="text"
                placeholder="Search for cars..."
                value={searchTerm}
                onChange={handleSearchChange}
                className="w-full py-2 pl-10 pr-4 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
          </div>

          <div className="hidden md:flex items-center space-x-6">
            <a href="/favorites" className="flex items-center text-gray-700 hover:text-blue-600">
              <Heart className="h-5 w-5" />
              <span className="ml-1">Favorites</span>
            </a>
            <a href="/cart" className="flex items-center text-gray-700 hover:text-blue-600">
              <ShoppingCart className="h-5 w-5" />
              <span className="ml-1">Cart</span>
            </a>
            <a href="/account" className="flex items-center text-gray-700 hover:text-blue-600">
              <User className="h-5 w-5" />
              <span className="ml-1">Account</span>
            </a>
          </div>

          <div className="md:hidden flex items-center">
            <button onClick={toggleMobileMenu} className="text-gray-700">
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4">
            <div className="relative mb-4">
              <input
                type="text"
                placeholder="Search for cars..."
                value={searchTerm}
                onChange={handleSearchChange}
                className="w-full py-2 pl-10 pr-4 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
            <div className="flex flex-col space-y-4">
              <a href="/favorites" className="flex items-center text-gray-700">
                <Heart className="h-5 w-5 mr-2" />
                <span>Favorites</span>
              </a>
              <a href="/cart" className="flex items-center text-gray-700">
                <ShoppingCart className="h-5 w-5 mr-2" />
                <span>Cart</span>
              </a>
              <a href="/account" className="flex items-center text-gray-700">
                <User className="h-5 w-5 mr-2" />
                <span>Account</span>
              </a>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;