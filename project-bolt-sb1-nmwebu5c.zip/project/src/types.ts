export interface CarType {
  id: string;
  brand: string;
  model: string;
  year: number;
  price: number;
  type: string;
  mileage: number;
  color: string;
  fuelType: string;
  transmission: string;
  description: string;
  features: string[];
  imageUrl: string;
}

export interface FilterProps {
  searchTerm: string;
  priceRange: [number, number];
  selectedBrands: string[];
  selectedTypes: string[];
}