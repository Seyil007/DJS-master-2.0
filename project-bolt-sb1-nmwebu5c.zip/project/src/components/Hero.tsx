import React from 'react';
import { ChevronRight } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <div className="relative bg-gradient-to-r from-blue-600 to-blue-800 text-white">
      <div className="absolute inset-0 bg-black opacity-20"></div>
      <div className="container mx-auto px-4 py-16 md:py-24 relative z-10">
        <div className="max-w-2xl">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Find Your Perfect Car</h1>
          <p className="text-xl mb-8">
            Browse our extensive collection of new and used vehicles. 
            From luxury sedans to family SUVs, we have the perfect car waiting for you.
          </p>
          <div className="flex flex-wrap gap-4">
            <a 
              href="#browse" 
              className="bg-white text-blue-600 px-6 py-3 rounded-md font-semibold hover:bg-gray-100 transition"
            >
              Browse Cars
            </a>
            <a 
              href="#special-offers" 
              className="bg-transparent border-2 border-white px-6 py-3 rounded-md font-semibold hover:bg-white hover:text-blue-600 transition"
            >
              Special Offers
            </a>
          </div>
        </div>
      </div>
      <div className="container mx-auto px-4 pb-8 relative z-10">
        <div className="bg-white rounded-lg shadow-lg p-6 text-gray-800 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <h3 className="text-xl font-semibold mb-2">Extensive Selection</h3>
            <p className="text-gray-600">
              Browse thousands of cars from all major brands in one place.
            </p>
          </div>
          <div className="text-center">
            <h3 className="text-xl font-semibold mb-2">Financing Options</h3>
            <p className="text-gray-600">
              Flexible payment plans and competitive rates available.
            </p>
          </div>
          <div className="text-center">
            <h3 className="text-xl font-semibold mb-2">Trusted Dealers</h3>
            <p className="text-gray-600">
              All our partners are vetted for quality and reliability.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;