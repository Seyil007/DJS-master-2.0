import React from 'react';
import { CarType } from '../types';
import { X, Heart, ShoppingCart, Check } from 'lucide-react';

interface CarDetailProps {
  car: CarType;
  onClose: () => void;
  isFavorite: boolean;
  onToggleFavorite: () => void;
}

const CarDetail: React.FC<CarDetailProps> = ({ car, onClose, isFavorite, onToggleFavorite }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="relative">
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 bg-white rounded-full p-2 shadow-md z-10"
          >
            <X className="h-5 w-5" />
          </button>
          <div className="h-64 md:h-80 overflow-hidden">
            <img 
              src={car.imageUrl} 
              alt={`${car.brand} ${car.model}`} 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
        
        <div className="p-6">
          <div className="flex flex-col md:flex-row md:justify-between md:items-start mb-6">
            <div>
              <h2 className="text-2xl font-bold mb-1">{car.brand} {car.model}</h2>
              <p className="text-gray-600">{car.year} • {car.type} • {car.transmission}</p>
            </div>
            <div className="mt-4 md:mt-0">
              <span className="text-3xl font-bold text-blue-600">${car.price.toLocaleString()}</span>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-xl font-semibold mb-4">Vehicle Details</h3>
              <div className="grid grid-cols-2 gap-y-3">
                <div className="text-gray-600">Brand</div>
                <div>{car.brand}</div>
                <div className="text-gray-600">Model</div>
                <div>{car.model}</div>
                <div className="text-gray-600">Year</div>
                <div>{car.year}</div>
                <div className="text-gray-600">Type</div>
                <div>{car.type}</div>
                <div className="text-gray-600">Mileage</div>
                <div>{car.mileage.toLocaleString()} miles</div>
                <div className="text-gray-600">Color</div>
                <div>{car.color}</div>
                <div className="text-gray-600">Fuel Type</div>
                <div>{car.fuelType}</div>
                <div className="text-gray-600">Transmission</div>
                <div>{car.transmission}</div>
              </div>
              
              <h3 className="text-xl font-semibold mt-8 mb-4">Description</h3>
              <p className="text-gray-700">{car.description}</p>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-4">Features</h3>
              <ul className="space-y-2">
                {car.features.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-2" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              
              <div className="mt-8 space-y-4">
                <button className="w-full bg-blue-600 text-white py-3 rounded-md font-semibold hover:bg-blue-700 transition flex items-center justify-center">
                  <ShoppingCart className="h-5 w-5 mr-2" />
                  Add to Cart
                </button>
                <button 
                  onClick={onToggleFavorite}
                  className={`w-full py-3 rounded-md font-semibold transition flex items-center justify-center ${
                    isFavorite 
                      ? 'bg-red-100 text-red-600 hover:bg-red-200' 
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  <Heart className={`h-5 w-5 mr-2 ${isFavorite ? 'fill-red-500' : ''}`} />
                  {isFavorite ? 'Remove from Favorites' : 'Add to Favorites'}
                </button>
                <button className="w-full bg-white border border-blue-600 text-blue-600 py-3 rounded-md font-semibold hover:bg-blue-50 transition">
                  Schedule Test Drive
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CarDetail;