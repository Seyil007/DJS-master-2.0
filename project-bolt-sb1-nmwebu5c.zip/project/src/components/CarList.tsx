import React, { useState } from 'react';
import { cars } from '../data/cars';
import { CarType } from '../types';
import { Heart, ChevronRight } from 'lucide-react';
import CarDetail from './CarDetail';

interface CarListProps {
  searchTerm: string;
  priceRange: [number, number];
  selectedBrands: string[];
  selectedTypes: string[];
  favorites: string[];
  onToggleFavorite: (carId: string) => void;
}

const CarList: React.FC<CarListProps> = ({ 
  searchTerm, 
  priceRange, 
  selectedBrands, 
  selectedTypes,
  favorites,
  onToggleFavorite
}) => {
  const [selectedCar, setSelectedCar] = useState<CarType | null>(null);
  const [showDetail, setShowDetail] = useState(false);

  const filteredCars = cars.filter(car => {
    // Filter by search term
    if (searchTerm && !`${car.brand} ${car.model}`.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }
    
    // Filter by price range
    if (car.price < priceRange[0] || car.price > priceRange[1]) {
      return false;
    }
    
    // Filter by selected brands
    if (selectedBrands.length > 0 && !selectedBrands.includes(car.brand)) {
      return false;
    }
    
    // Filter by selected types
    if (selectedTypes.length > 0 && !selectedTypes.includes(car.type)) {
      return false;
    }
    
    return true;
  });

  const handleCarClick = (car: CarType) => {
    setSelectedCar(car);
    setShowDetail(true);
  };

  const closeDetail = () => {
    setShowDetail(false);
  };

  return (
    <div>
      {filteredCars.length === 0 ? (
        <div className="text-center py-10">
          <p className="text-xl text-gray-600">No cars match your search criteria.</p>
          <p className="text-gray-500 mt-2">Try adjusting your filters or search term.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCars.map(car => (
            <div 
              key={car.id} 
              className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition cursor-pointer"
              onClick={() => handleCarClick(car)}
            >
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={car.imageUrl} 
                  alt={`${car.brand} ${car.model}`} 
                  className="w-full h-full object-cover"
                />
                <button 
                  className="absolute top-2 right-2 p-2 bg-white rounded-full shadow-sm hover:bg-gray-100 transition"
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleFavorite(car.id);
                  }}
                >
                  <Heart 
                    className={`h-5 w-5 ${favorites.includes(car.id) ? 'fill-red-500 text-red-500' : 'text-gray-400'}`} 
                  />
                </button>
              </div>
              <div className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-lg font-semibold">{car.brand} {car.model}</h3>
                  <span className="text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded">{car.year}</span>
                </div>
                <p className="text-gray-600 mb-2">{car.type} • {car.fuelType} • {car.transmission}</p>
                <div className="flex justify-between items-center mt-4">
                  <span className="text-xl font-bold text-blue-600">${car.price.toLocaleString()}</span>
                  <button className="flex items-center text-blue-600 hover:text-blue-800">
                    Details <ChevronRight className="h-4 w-4 ml-1" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      
      {showDetail && selectedCar && (
        <CarDetail 
          car={selectedCar} 
          onClose={closeDetail} 
          isFavorite={favorites.includes(selectedCar.id)}
          onToggleFavorite={() => onToggleFavorite(selectedCar.id)}
        />
      )}
    </div>
  );
};

export default CarList;